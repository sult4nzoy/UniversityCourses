#! python3
#Filnamn: omsu2400_2.1_v1.py
#Skrivet av: Omar Sultanzoy
#Skapat datum 2024-10-01
#Senast ändrad: 2024-10-01
#Kurs: Grundläggande Datavetenskap
#Handledare: Karl Pettersson
#Beskrivning: Detta program låter användaren skriva in en siffra, om den är udda så kommer det printas "det är en udda siffra", annars skriver den "siffran är jämn"

siffra = int(input("Skriv in ett heltal: "))
if siffra % 2 == 0:
    print(siffra, "är ett jämnt tal!")
else:
    print(siffra, "är en udda siffra!")


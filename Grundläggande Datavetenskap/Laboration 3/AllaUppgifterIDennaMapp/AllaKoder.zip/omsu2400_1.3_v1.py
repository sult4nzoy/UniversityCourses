#! python3
#Filnamn: omsu2400_1.3_v1.py
#Skrivet av: Omar Sultanzoy
#Skapat datum 2024-09-30
#Senast ändrad: 2024-10-01
#Kurs: Grundläggande Datavetenskap
#Handledare: Karl Pettersson
#Beskrivning: Programmet låter användare mata in en siffra, sedan räknar den ut momsen, printar momsen och pris+moms.

prisUtanMoms = float(input("Mata in pris, utan moms: ")) 
momsSats = 0.25 * prisUtanMoms
moms = momsSats + prisUtanMoms
print("Moms:", float(momsSats), "  &  ", "Pris med moms:", float(moms))
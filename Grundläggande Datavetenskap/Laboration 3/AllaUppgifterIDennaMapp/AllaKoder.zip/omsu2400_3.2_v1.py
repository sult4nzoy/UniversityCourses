#! python3
#Filnamn: omsu2400_3.2_v1.py
#Skrivet av: Omar Sultanzoy
#Skapat datum 2024-10-01
#Senast ändrad: 2024-10-01
#Kurs: Grundläggande Datavetenskap
#Handledare: Karl Pettersson
#Beskrivning: Programmet låter användare skriva in 2 tal och sedan hittar den störtsta gemenssamma nämnare. 

M = int(input("Ange det större av de 2 talen: "))
N = int(input("Ange det mindre av de 2 talen: "))
R = M % N
while R != 0:
    M = N
    N = R
    R = M % N
print("Största gemensamma nämnaren är: ", N)
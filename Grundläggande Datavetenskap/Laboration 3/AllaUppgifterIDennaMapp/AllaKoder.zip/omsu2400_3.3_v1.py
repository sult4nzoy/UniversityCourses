#! python3
#Filnamn: omsu2400_3.3_v1.py
#Skrivet av: Omar Sultanzoy
#Skapat datum 2024-10-01
#Senast ändrad: 2024-10-02
#Kurs: Grundläggande Datavetenskap
#Handledare: Karl Pettersson
#Beskrivning: Detta program tillåter användare att skriva in en siffra, om det är ett skottår så printar den "#### är ett skottår, annars printar den "#### är inte ett skottår".
År = int(input("Skriv in ett skottår: "))
if År % 4 == 0:
    if År % 100 == 0:
        if År % 400 == 0:
            print(År, " är ett skottår!")
        else: print(År, "är inte ett skottår!")
    else: print(År, "är ett skottår!")    
else: print(År,"är inte ett skottår!")
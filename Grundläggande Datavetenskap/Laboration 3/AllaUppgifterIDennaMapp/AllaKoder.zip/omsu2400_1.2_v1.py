#! python3
#Filnamn: omsu2400_1.2_v1.py
#Skrivet av: Omar Sultanzoy
#Skapat datum 2024-10-01
#Senast ändrad: 2024-10-02
#Kurs: Grundläggande Datavetenskap
#Handledare: Karl Pettersson
#Beskrivning: Programmet adderar integers med strings
a = 1
b = "Ett"
c = 5.2
d = "5.2"
e = "3"
aa = "Antal" + str(a)   #Här behöver man ändra "a" till en string eftersom att det inte går att plussa en string med en integer. 
bb = "Antal" + b
cc = "Antal" + str(c)   #Här behöver man ändra "c" till en string eftersom att det inte går att plussa en string med en integer. 
dd = "Antal" + d
ee = "Antal" + e
print( aa )
print( bb )
print( cc )
print( dd )
print( ee )
aa = 10 + a
bb = str(10) + b        #Här behöver man ändra "10" till en string eftersom det inte går att plussa en string med integer
cc = 10 + c
dd = 10 + float(d)      #Här behöver man ändra "d" till en float eftersom att det inte går att plussa ord med siffror, float användes eftersom det är "5.2"
ee = 10 + int(e)        #Här behöver man ändra "e" till en int eftersom att det inte går att plussa ord med siffror, int användes då det inte är ett decimal.
print( aa )
print( bb )
print( cc )
print( dd )
print( ee )
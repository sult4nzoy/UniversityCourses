<?php
/*
Författare: Omar Sultanzoy
Kurs: Webbprogrammering - Projektarbete
Syfte med klassen: Hanterar kommunikation med orders och order_items.
*/
class Order
{

    private $dbConnection;

    function __construct($dbConnection)
    {
        $this->dbConnection = $dbConnection;
    }

    function createOrder($userId, $total, $status, $date)
    {
        $this->dbConnection->query("INSERT INTO orders (user_id, order_total, order_status, order_created_at) VALUES ($userId, $total, '$status', '$date')");
        return $this->dbConnection->lastInsertId();
    }

    function addOrderItem($orderId, $productId, $quantity, $price)
    {
        $this->dbConnection->query("INSERT INTO order_items (order_id, product_id, quantity, item_price) VALUES ($orderId, $productId, $quantity, $price)");
    }

    function getAllOrders()
    {
        return $this->dbConnection->query("SELECT * FROM orders")->fetchAll();
    }

    function getOrderById($id)
    {
        return $this->dbConnection->query("SELECT * FROM orders WHERE order_id = $id")->fetch();
    }

    function getItemsByOrderId($orderId)
    {
        return $this->dbConnection->query("SELECT * FROM order_items WHERE order_id = $orderId")->fetchAll();
    }

    function updateOrderStatus($id, $status)
    {
        $this->dbConnection->query("UPDATE orders SET order_status = '$status' WHERE order_id = $id");
    }

    function deleteOrder($id)
    {
        $this->dbConnection->query("DELETE FROM order_items WHERE order_id = $id");
        $this->dbConnection->query("DELETE FROM orders WHERE order_id = $id");
    }

    function getOrdersByUserId($userId)
    {
        return $this->dbConnection->query("SELECT * FROM orders WHERE user_id = $userId")->fetchAll();
    }
}

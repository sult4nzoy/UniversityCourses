<?php
/*
Författare: Omar Sultanzoy
Kurs: Webbprogrammering - Projektarbete
Kursansvarig: Mikael Hasselmalm & Jan-Erik Jonsson
Syfte med klassen: Denna klass hanterar all kommunikation med databasen. 
Den skapar en anslutning till databasen och har en funktion för att 
returnera den anslutningen så att den kan användas i andra delar av hemsidan.
*/
class Database
{

    private $db;

    function __construct()
    {
        $host = 'studentmysql.miun.se';
        $db_name = 'omsu2400';
        $user = 'omsu2400';
        $password = 'v00pa9wc';
        try {
            $this->db = new PDO("mysql:host=$host;dbname=$db_name", $user, $password);
        } 
        catch (PDOException $e) {
            echo "Connection failed: " . $e->getMessage();
        }
    }

    function getConnection()
    {
        return $this->db;
    }
}

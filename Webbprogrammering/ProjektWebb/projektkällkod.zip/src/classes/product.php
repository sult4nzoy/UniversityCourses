<?php
/*
Författare: Omar Sultanzoy
Kurs: Webbprogrammering - Projektarbete
Kursansvarig: Mikael Hasselmalm & Jan-Erik Jonsson
Syfte med klassen: Denna klass hanterar kommunikation med produkter i databasen. Den har funktioner
för att hämta alla produkter, hämta en produkt baserat på id, lägga till en produkt, uppdatera en 
produkt, ta bort en produkt och uppdatera lagersaldo för en produkt.
*/
class Product
{
    private $dbConnection;

    function __construct($dbConnection)
    {
        $this->dbConnection = $dbConnection;
    }

    function getAllProducts()
    {
        if ($this->dbConnection->query("SELECT * FROM products")->fetchAll() == false) {
            echo "Inga produkter hittades i databasen.";
        }
        return $this->dbConnection->query("SELECT * FROM products")->fetchAll();
    }

    function getProductById($id)
    {
        return $this->dbConnection->query("SELECT * FROM products WHERE product_id = $id")->fetch();
    }

    function addProduct($name, $description, $price, $stock, $image)
    {
        $sql = "INSERT INTO products (product_name, product_description, product_price, product_stock, product_image) 
            VALUES ('$name', '$description', $price, $stock, '$image')";

        $result = $this->dbConnection->query($sql);
    }

    function updateProduct($id, $name, $price, $stock)
    {
        $sql = "UPDATE products 
            SET product_name = '$name', 
                product_price = $price, 
                product_stock = $stock 
            WHERE product_id = $id";

        $this->dbConnection->query($sql);
    }

    function deleteProduct($id)
    {
        $this->dbConnection->query("DELETE FROM order_items WHERE product_id = $id");
        $this->dbConnection->query("DELETE FROM products WHERE product_id = $id");
    }

    function updateStock($id, $newStock)
    {
        $this->dbConnection->query("UPDATE products SET product_stock = $newStock WHERE product_id = $id");
    }
}

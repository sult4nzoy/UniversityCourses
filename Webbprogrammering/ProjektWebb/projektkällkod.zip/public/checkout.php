<?php
/*
Författare: Omar Sultanzoy
Kurs: Webbprogrammering - Projektarbete
Kursansvarig: Mikael Hasselmalm & Jan-Erik Jonsson
Syfte med filen: Denna sida hanterar betalningsprocessen för produkter i kundvagnen. Den är tillgänglig för alla användare.
*/
session_start();
require_once '../src/classes/database.php';
require_once '../src/classes/product.php';
require_once '../src/classes/order.php';

$db = (new Database())->getConnection();
$productHandler = new Product($db);
$orderHandler = new Order($db);

$orderNum = null;

if (isset($_GET['success']) && $_GET['success'] == 'true' && !empty($_SESSION['cart'])) {
    
    $total = 0;
    $itemsToSave = [];

    foreach ($_SESSION['cart'] as $id => $qty) {
        $p = $productHandler->getProductById($id);
        if ($p) {
            $total += ($p['product_price'] * $qty);
            $itemsToSave[] = [
                'id' => $id, 
                'qty' => $qty, 
                'price' => $p['product_price'], 
                'current_stock' => $p['product_stock'],
                'name' => $p['product_name']
            ];
        }
    }

    $orderNum = $orderHandler->createOrder($_SESSION['user_id'], $total, 'Betald', date('Y-m-d H:i'));

    if ($orderNum) {
        foreach ($itemsToSave as $item) {

            $orderHandler->addOrderItem($orderNum, $item['id'], $item['qty'], $item['price']);
            
            $newStock = $item['current_stock'] - $item['qty'];
            $productHandler->updateStock($item['id'], $newStock);
        }

        unset($_SESSION['cart']);
    }
}

include "../includes/header.html";
?>

<div class="container" style="text-align:center; padding: 50px 0;">
    <?php if ($orderNum): ?>
        <h1 style="color: #28a745;">Betalning genomförd!</h1>
        <p>Tack för ditt köp. Din order <strong>#<?php echo $orderNum; ?></strong> är nu registrerad.</p>
        <br>
        <a href="index.php" class="btn">Tillbaka till butiken</a>
    <?php else: ?>
        <h2>Något gick fel</h2>
        <p>Vi kunde inte hitta din beställning eller så är varukorgen tom.</p>
        <a href="cart.php" class="btn">Gå tillbaka till varukorgen</a>
    <?php endif; ?>
</div>

<?php include '../includes/footer.html'; ?>
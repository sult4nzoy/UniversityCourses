<?php
/*
Författare: Omar Sultanzoy
Kurs: Webbprogrammering - Projektarbete
Kursansvarig: Mikael Hasselmalm & Jan-Erik Jonsson
Syfte med filen: Denna sida är startsidan för hemsidan. Den visar alla produkter som finns i databasen och välkomnar användaren.
Den är tillgänglig för alla användare.
*/
session_start();
require_once '../src/classes/database.php';
require_once '../src/classes/product.php';
require_once '../src/classes/users.php';
$db = (new Database())->getConnection();
$productHandler = new Product($db);
$products = $productHandler->getAllProducts();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

if (isset($_SESSION['user_rights']) && $_SESSION['user_rights'] == 'admin') {

    include '../includes/adminheader.html';
} else {

    include '../includes/header.html';
}

?>
<div class="container">
    <h1>Välkommen, <?php echo $_SESSION['username'] ?>!</h1>
    <hr>
    <div class="product-grid">
        <?php foreach ($products as $p): ?>
            <div class="product-card">
                <img src="../../writeable/images/<?php echo $p['product_image']; ?>" alt="Produktbild" style="width:90%; height: 180px; border-radius:5px;">
                <h3><?php echo $p['product_name']; ?></h3>
                <p class="price"><?php echo $p['product_price']; ?> kr</p>
                <a href="product.php?id=<?php echo $p['product_id']; ?>" class="btn">Visa mer</a>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php include '../includes/footer.html'; ?>
<?php
/*
Författare: Omar Sultanzoy
Kurs: Webbprogrammering - Projektarbete
Kursansvarig: Mikael Hasselmalm & Jan-Erik Jonsson
Syfte med filen: Denna sida visar detaljer om en enskild produkt som användaren klickat in på. Den är tillgänglig för alla användare.
*/
session_start();
require_once '../src/classes/database.php';
require_once '../src/classes/product.php';

$db = (new Database())->getConnection();
$productHandler = new Product($db);
$p = $productHandler->getProductById($_GET['id']);

if (!$p) {
    header("Location: index.php");
    exit;
}
if(isset($_SESSION['user_rights']) && $_SESSION['user_rights'] == 'admin') {
    include '../includes/adminheader.html';
} else {
    include '../includes/header.html';
}

?>

<div class="container">
    <div class="product-detail">
        <img src="../../writeable/images/<?php echo $p['product_image']; ?>">
        
        <div class="product-info">
            <h1><?php echo $p['product_name']; ?></h1>
            <p class="price">Pris: <?php echo $p['product_price']; ?> kr</p>
            <p><strong>Beskrivning:</strong> <?php echo $p['product_description']; ?></p>
            <p><strong>Lager:</strong> <?php echo $p['product_stock']; ?> st</p>

            <form method="post" action="cart.php">
                <input type="hidden" name="product_id" value="<?php echo $p['product_id']; ?>">
                <button type="submit">Lägg i varukorgen</button>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.html'; ?>